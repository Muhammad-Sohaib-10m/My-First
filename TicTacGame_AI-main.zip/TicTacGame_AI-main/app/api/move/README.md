This folder contains the serverless route for the AI move. Vercel will deploy it automatically under /api/move.
